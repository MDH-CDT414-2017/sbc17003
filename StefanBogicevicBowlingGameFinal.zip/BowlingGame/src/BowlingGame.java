/** BowlingGame Score calculator 
 *
 * @author CDT414 Student: Stefan Bogićević sbc17003
 * @version 1.0 
 * @date 2016-11-24
 */
public class BowlingGame {

	/** BowlingGame Score calculator constructor which require string as input 
	 * @param game Expected format "[n,n][n,n]..[n,n]"
	 * 
	 */	 
	public BowlingGame(String game)
	{	
		
	}
	
	/** getScore method returns a score of current Bowling game or -1 if error
	 * 
	 * @return Integer value of Bowling score, in case of error return value is -1 
	 */
	public int getScore(String s) {
		String[] items = s.replaceAll("\\[", "").replaceAll("\\]", " ").replaceAll("\\s", "").split(",");

		int[] results = new int[items.length];
		int[] results2 = new int[items.length];
		int score = 0;
		for (int i = 0; i < results2.length; i+=2) {
			results2[i] = Integer.parseInt(items[i]);
		}
		for (int i = 1; i < items.length; i+=2) {
			results[i] = Integer.parseInt(items[i]);
		}
		for (int i = 1; i < results.length; i+=2) {
		    try {
		       System.out.println("[" + results2[i-1] + "," + results[i] + "]");
		         if (results2[i-1] + results[i] == 10 && results2[i-1]==10 && i<19) {
		    	   if (results2[i+1] == 10) {
						score += 10 + results2[i+1] + results2[i+3];
						continue;
					} else {
						score += 10 + results2[i+1] + results[i+2];
						continue;
					}
			   }
		       else if (results2[i-1] + results[i] == 10 && results2[i-1]!=10) {
		    	   score += 10 + results2[i+1];
					continue;
		       }
		       else if (results2[i-1] + results[i] > 10 ) {
						return -1;
				   }
		       else if (results.length>20 && (results[19]+results2[18]) !=10) {
		    	   return -1;
			}
		       score = results2[i-1] + results[i] + score;
		    } catch (NumberFormatException nfe) {
		        //NOTE: write something here if you need to recover from formatting errors
		    };
		}
		if (score > 300 || score <0) {
			return -1;
		}
		return score;
	}
	
		
		public String getOneFrame(String s) {
			String[] items = s.replaceAll("\\[", "").replaceAll("\\]", " ").replaceAll("\\s", "").split(",");
			int[] results = new int[items.length];
			int[] results2 = new int[items.length];
			int score = 0;
			for (int i = 0; i < results2.length; i+=2) {
				results2[i] = Integer.parseInt(items[i]);
			}
			for (int i = 1; i < items.length; i+=2) {
				results[i] = Integer.parseInt(items[i]);
			}
			for (int i = 1; i < results.length; i+=2) {
			    try {
			       score = results2[i-1] + results[i] + score;
			       if (results2[i-1] + results[i] < 10) {
					return "Open";
			       }
			       
			       else  if (results2[i-1] + results[i] == 10 && results2[i-1]==10) {
						return "Strike";
				   }
			       else if (results2[i-1] + results[i] == 10 && results2[i-1]!=10) {
						return "Stroke";
				   }
			       else if (results2[i-1] + results[i] > 10 ) {
							return "Wrong frame input";
					   }
			    } catch (NumberFormatException nfe) {
			        //NOTE: write something here if you need to recover from formatting errors
			    };
			}	
		return String.valueOf(score);
		}
}
	
	

