/** BowlingGameTest 
 *
 * @author CDT414 Student:
 * @version 1.0 
 * @date 2016-11-24
 */
import org.junit.Test;

import junit.framework.TestCase;

/** BowlingGame Score calculator test cases 
 *  
 */	 
public class BowlingGameTest extends TestCase {
	BowlingGame bowlingGame = new BowlingGame("");
	/** test01 
	 * 	
	 *  If no game is provided, score should be -1 (error)   
	 */	     
	public void test01() { // test if open
        assertEquals("Open", bowlingGame.getOneFrame("[1,5]"));
    }	
	public void test02() { // test if strike
        assertEquals("Strike", bowlingGame.getOneFrame("[10,0]"));
    }	
	public void test03() { // test if spare
        assertEquals("Stroke", bowlingGame.getOneFrame("[5,5]"));
    }	
	public void test04() { // test if sum of one frame excedes 10
        assertEquals("Wrong frame input", bowlingGame.getOneFrame("[8,5]"));
    }	
	public void test05() { // test score if all open
		assertEquals(81, bowlingGame.getScore("[1,5],[3,6],[7,2],[3,6],[4,4],[5,3],[3,3],[4,5],[8,1],[2,6]"));
    }	
	public void test06() { // test score if have strike
		assertEquals(80, bowlingGame.getScore("[6,1],[2,4],[10,0],[3,4],[1,4],[5,4],[6,1],[6,2],[1,4],[5,4]"));
    }	
	public void test07() { // test score if have two strike in a row 
		assertEquals(79, bowlingGame.getScore("[10,0],[10,0],[4,1],[4,1],[1,4],[1,4],[4,1],[1,4],[1,4],[1,4]"));
    }	
	public void test08() { // test score if there is one spare 
		assertEquals(119, bowlingGame.getScore("[10,0],[10,0],[4,1],[4,1],[1,4],[1,4],[10,0],[4,6],[10,0],[1,4]"));
    }	
	public void test09() { // test score if there is more than one spare 
		assertEquals(79, bowlingGame.getScore("[6,1],[2,4],[4,6],[3,4],[1,4],[5,4],[6,1],[5,5],[1,4],[5,4]"));
    }	
	public void test10() { // test score if last frame is spare
		assertEquals(85, bowlingGame.getScore("[6,1],[2,4],[4,6],[3,4],[1,4],[5,4],[6,1],[5,5],[1,4],[5,5],[5,]"));
    }	
	public void test11() { // test score if last frame is strike
		assertEquals(88, bowlingGame.getScore("[6,1],[2,4],[4,6],[3,4],[1,4],[5,4],[6,1],[5,5],[1,4],[10,0],[5,3]"));
    }	
	@Test // Let's test now if there is no spare or strike in the last frame and we put additional throw. 
	// It should return -1.
	public void test12() { 
		assertEquals(-1, bowlingGame.getScore("[6,1],[2,4],[4,6],[3,4],[1,4],[5,4],[6,1],[5,5],[1,4],[3,4],[5,6]"));
	}
	public void test13() { // test perfect game
		assertEquals(300, bowlingGame.getScore("[10,0],[10,0],[10,0],[10,0],[10,0],[10,0],[10,0],[10,0],[10,0],[10,0],[10,0],[10,0]"));
	}

}